const searchInput = document.querySelector('#search');
const h3 = document.querySelector('#result');
function debounce(fun, delay = 1000) {}
const fun = (e) => {
    //API call
    h3.textContenet = e.target.value;

};

searchInput.addEventListener('keyup', debounce(fun))
